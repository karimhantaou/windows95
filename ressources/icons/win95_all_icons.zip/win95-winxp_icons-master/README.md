# win95-winxp_icons

Here's all of the default icons shipped with
- Windows 95
- Windows 98
- Windows 2000 (my favorite)
- Windows XP

![screenshot](http://orig11.deviantart.net/6567/f/2016/069/d/f/win95__win98__win2k__winxp_default_icons_by_trapd00r-d9ukk4h.png)
